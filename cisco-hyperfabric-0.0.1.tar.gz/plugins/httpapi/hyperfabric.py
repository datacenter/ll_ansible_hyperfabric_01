# -*- coding: utf-8 -*-

# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.
#
# SPDX-License-Identifier: MPL-2.0

# Copyright: (c) 2025, Lionel Hercot (@lhercot) <lhercot@cisco.com>

from __future__ import absolute_import, division, print_function

__metaclass__ = type

DOCUMENTATION = """
---
name: hyperfabric
short_description: Cisco Nexus Hyperfabric Ansible HTTPAPI Plugin.
description:
- This Hyperfabric plugin provides the HTTPAPI transport methods needed to initiate
  a connection to the Hyperfabric service, send API requests and process the response.
version_added: "0.0.1"
"""

import os
import re
import json
import pickle
import traceback
import mimetypes
import sys
import tempfile
from ansible.module_utils.six import PY3
from ansible.module_utils._text import to_native, to_text
from ansible.module_utils.connection import ConnectionError
from urllib.error import HTTPError
from ansible.plugins.httpapi import HttpApiBase

# try:
#     from requests_toolbelt.multipart.encoder import MultipartEncoder

#     HAS_MULTIPART_ENCODER = True
# except ImportError:
#     HAS_MULTIPART_ENCODER = False

# if sys.version_info.major == 2:
#     from StringIO import StringIO  # For Python 2+
# else:
#     from io import StringIO  # For Python 3+


class HttpApi(HttpApiBase):
    def __init__(self, *args, **kwargs):
        super(HttpApi, self).__init__(*args, **kwargs)
        self.platform = "cisco.hyperfabric"
        self.headers = {"Content-Type": "application/json"}
        # self.default_host = "hyperfabric.cisco.com"
        self.base_path = "/api/v1"
        self.params = {}

        self.error = None
        self.method = "GET"
        self.path = ""
        self.status = -1
        self.info = {}

    def get_platform(self):
        return self.platform

    def set_params(self, params):
        self.params = params

    def login(self, username, password):
        """Log in to Hyperfabric"""
        # Perform login request
        self.connection.queue_message("info", "login() - login method called for {0}".format(self.connection.get_option("host")))
        if self.connection._auth is None:
            self.connection.queue_message("info", "login() - previous auth not found sending login POST to {0}".format(self.connection.get_option("host")))

    def logout(self):
        self.connection.queue_message("info", "logout() - logout method called for {0}".format(self.connection.get_option("host")))
        self.connection._auth = None

    def send_request(self, method, path, data=None):
        """This method handles all Hyperfabric REST API requests other than login"""

        self.error = None
        self.path = ""
        self.status = -1
        self.info = {}
        self.method = "GET"
        if method is not None:
            self.method = method

        self.connection.queue_message("info", "send_request() - send_request method called")

        if self.params.get("host") is not None:
            if self.connection._connected is True and self.params.get("host") != self.connection.get_option("host"):
                self.connection._connected = False
                self.connection.queue_message(
                    "info",
                    "send_request() - reseting connection as host has changed from {0} to {1}".format(
                        self.connection.get_option("host"), self.params.get("host")
                    ),
                )
            self.connection.set_option("host", self.params.get("host"))

        if self.params.get("port") is not None:
            self.connection.set_option("port", self.params.get("port"))

        if self.params.get("use_proxy") is not None:
            self.connection.set_option("use_proxy", self.params.get("use_proxy"))

        if self.params.get("use_ssl") is not None:
            self.connection.set_option("use_ssl", self.params.get("use_ssl"))

        if self.params.get("validate_certs") is not None:
            self.connection.set_option("validate_certs", self.params.get("validate_certs"))

        if self.params.get("timeout") is not None:
            self.connection.set_option("persistent_command_timeout", self.params.get("timeout"))

        # Support Hyperfabric API Token authorization within the session_key option.
        session_key = self.connection.get_option("session_key")
        if session_key and "Authorization" not in session_key.keys():
            self.connection.queue_message(
                "debug", "send_request() - authorizing with API Token defined in `ansible_httpapi_session_key` but changing header key name"
            )
            session_key_header = {
                "Authorization": "Bearer {}".format(list(session_key.values())[0]),
            }
            self.connection.set_option("session_key", session_key_header)
        elif session_key:
            self.connection.queue_message(
                "debug",
                "send_request() - authorizing with Hyperfabric API Token header defined in `ansible_httpapi_session_key`.",
            )

        # Perform some very basic path input validation.
        path = str(path)
        if path[0] != "/":
            self.error = dict(code=self.status, message="Value of <path> does not appear to be formated properly")
            raise ConnectionError(json.dumps(self._verify_response(None, method, path, None)))
        full_path = self.base_path + path
        try:
            self.connection.queue_message("info", "send_request() - connection.send({0}, {1}, {2}, {3})".format(path, data, method, self.headers))
            response, rdata = self.connection.send(self.base_path + path, data, method=method, headers=self.headers)
        except ConnectionError as connection_err:
            self.connection.queue_message("info", "send_request() - ConnectionError Exception: {0}".format(connection_err))
            raise
        except HTTPError as e:
            # return self._verify_response(None, method, full_path, rdata)
            rdata = e.fp.read()
            self.error = dict(code=self.status, message="Hyperfabric HTTPError HTTPAPI send_request() Exception: {0} - {1} | {2} | {3}".format(e.url, e.code, e.reason, rdata))
            return self._verify_response(e.fp, method, full_path, rdata)
        except Exception as e:
            # if self.status == 401:
            #     self.error = dict(code=self.status, message="Hyperfabric HTTPAPI 401 Exception: {0} - {1}".format(response, rdata))
            #     return self._verify_response(response, method, full_path, rdata)
            self.connection.queue_message("info", "send_request() - Generic Exception: {0}".format(e))
            if self.error is None:
                self.error = dict(code=self.status, message="Hyperfabric HTTPAPI send_request() Exception: {0} - {1}".format(e, traceback.format_exc()))
            raise ConnectionError(json.dumps(self._verify_response(None, method, full_path, None)))
        return self._verify_response(response, method, full_path, rdata)

    def _verify_response(self, response, method, path, data):
        """Process the return code and response object from Hyperfabric"""
        response_data = None
        response_code = -1
        self.info.update(dict(url=path))
        if data is not None:
            response_data = self._response_to_json(data)
        if response is not None:
            response_code = response.getcode()
            path = response.geturl()
            self.info.update(self._get_formated_info(response))

            # Handle possible Hyperfabric error information
            if response_code not in [200, 201, 202, 204]:
                self.error = dict(code=self.status, message=response_data)

        self.info["method"] = method
        if self.error is not None:
            self.info["error"] = self.error
        # if msg is None:
        #     self.info['msg'] = str(self.info)
        # else:
        #     self.info['msg'] = msg
        self.info["body"] = response_data

        return self.info

    def _response_to_json(self, response_data):
        """Convert response_data to json format"""
        try:
            response_value = response_data.getvalue()
        except Exception:
            response_value = response_data
        response_text = to_text(response_value)
        try:
            return json.loads(response_text) if response_text else {}
        # JSONDecodeError only available on Python 3.5+
        except Exception as e:
            # Expose RAW output for troubleshooting
            self.error = dict(code=-1, message="Unable to parse output as JSON, see 'raw' output. {0}".format(e))
            self.info["raw"] = response_text
            return

    def _get_formated_info(self, response):
        """The code in this function is based on Ansible fetch_url code at https://github.com/ansible/ansible/blob/devel/lib/ansible/module_utils/urls.py"""
        info = dict(msg="OK (%s bytes)" % response.headers.get("Content-Length", "unknown"), url=response.geturl(), status=response.getcode())
        # Lowercase keys, to conform to py2 behavior, so that py3 and py2 are predictable
        info.update(dict((k.lower(), v) for k, v in response.info().items()))

        # Don't be lossy, append header values for duplicate headers
        # In Py2 there is nothing that needs done, py2 does this for us
        if PY3:
            temp_headers = {}
            for name, value in response.headers.items():
                # The same as above, lower case keys to match py2 behavior, and create more consistent results
                name = name.lower()
                if name in temp_headers:
                    temp_headers[name] = ", ".join((temp_headers[name], value))
                else:
                    temp_headers[name] = value
            info.update(temp_headers)
        return info
