#!/usr/bin/python
# -*- coding: utf-8 -*-

# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.
#
# SPDX-License-Identifier: MPL-2.0

# Copyright: (c) 2025, Lionel Hercot (@lhercot) <lhercot@cisco.com>

from __future__ import absolute_import, division, print_function

__metaclass__ = type

ANSIBLE_METADATA = {"metadata_version": "1.1", "status": ["preview"], "supported_by": "community"}

DOCUMENTATION = r"""
---
module: hyperfabric_nodes
version_added: "0.0.1"
short_description: Manages Nexus Hyperfabric fabric nodes
description:
- Manages Cisco Nexus Hyperfabric fabric nodes
author:
- Lionel Hercot (@lhercot)
options:
  state:
    description:
    - The behavior to use to modify the Hyperfabric configuration during module completion.
    type: str
    choices:
      - merged
      - present
      - deleted
      - absent
    default: merged
  fabric_name:
    description:
    - The name of the Fabric.
    type: str
    required: true
  config:
    description:
    - List of details of the fabric nodes being managed.
    type: list
    elements: dict
    suboptions:
      name:
        description:
        - The name of the Node.
        type: str
        required: true
        aliases: [ node_name ]
      model_name:
        description:
        - The name of model of the Node.
        type: str
        required: true
        aliases: [ model, pid ]
        choices: [ HF6100-32D, HF6100-60L4D ]
      roles:
        description:
        - A list of roles for the Node.
        type: list
        elements: string
        required: true
        choices: [ LEAF, SPINE ]
      description:
        description:
        - The description is a user defined field to store notes about the Node.
        type: str
      serial_number:
        description:
        - The serial number of Device to be associated with the Node.
        type: str
        aliases: [ serial ]
      location:
        description:
        - The location is a user defined location of the Node.
        type: str
      labels:
        description:
        - A list of user-defined labels that can be used for grouping and filtering Nodes.
        type: list
        elements: string
      annotations:
        description:
        - A list of key-value annotations to store user-defined data including complex data such as JSON.
        type: list
        elements: dict
        suboptions:
          name:
            description:
            - The name used to uniquely identify the annotation.
            type: str
            required: true
          value:
            description:
            - The value of the annotation.
            type: str
            required: true
          data_type:
            description:
            - The type of data stored in the value of the annotation.
            type: str
            choices: [ STRING, INT32, UINT32, INT64, UINT64, BOOL, TIME, UUID, DURATION, JSON ]
            default: STRING
extends_documentation_fragment:
- cisco.hyperfabric.modules
- cisco.hyperfabric.check_mode
"""

EXAMPLES = r"""
- name: Create nodes
  cisco.hyperfabric.hyperfabric_nodes:  
    state: merged
    fabric_name: ansible-fabric-1
    config:
      - name: leaf-1
        model: HF6100-60L4D
        roles: ["LEAF"]
      - name: leaf-2
        model: HF6100-60L4D
        roles: ["LEAF"]
      - name: spine-1
        model: HF6100-32D
        roles: ["SPINE"]
      - name: spine-2
        model: HF6100-32D
        roles: ["SPINE"]
  register: create_nodes

- name: Delete nodes
  cisco.hyperfabric.hyperfabric_nodes:  
    state: deleted
    fabric_name: ansible-fabric-1
    config:
      - name: leaf-1
        model: HF6100-60L4D
        roles: ["LEAF"]
      - name: leaf-2
        model: HF6100-60L4D
        roles: ["LEAF"]
      - name: spine-1
        model: HF6100-32D
        roles: ["SPINE"]
      - name: spine-2
        model: HF6100-32D
        roles: ["SPINE"]
  register: delete_nodes
"""

RETURN = r"""
"""

from copy import deepcopy
from datetime import datetime as dt, timedelta
from ansible.module_utils.basic import AnsibleModule
from ansible_collections.cisco.hyperfabric.plugins.module_utils.hyperfabric import HyperfabricModule, hyperfabric_argument_spec


def annotations_spec():
    return dict(
        name=dict(type="str", required=True),
        value=dict(type="str", required=True),
        data_type=dict(type="str", default="STRING", choices=["STRING", "INT32", "UINT32", "INT64", "UINT64", "BOOL", "TIME", "UUID", "DURATION", "JSON"])
    )


def node_config_spec():
    return dict(
        name=dict(type="str", required=True, aliases=["node_name"]),
        model_name=dict(type="str", required=True, aliases=["model", "pid"], choices=["HF6100-32D", "HF6100-60L4D"]),
        roles=dict(type="list", elements="str", required=True, choices=["LEAF", "SPINE"]),
        description=dict(type="str"),
        serial_number=dict(type="str"),
        location=dict(type="str"),
        labels=dict(type="list", elements="str"),
        annotations=dict(type="list", elements="dict", options=annotations_spec()),
    )


def main():
    argument_spec = hyperfabric_argument_spec()
    argument_spec.update(
        fabric_name=dict(type="str", required=True),
        config=dict(type="list", elements="dict", options=node_config_spec()),
        state=dict(
            default="merged",
            choices=["merged", "present", "absent", "deleted"],
        ),
    )

    module = AnsibleModule(
        argument_spec=argument_spec,
        supports_check_mode=True,
    )

    hyperfabric = HyperfabricModule(module)

    fabric_name = hyperfabric.params.get("fabric_name")
    state = hyperfabric.params.get("state")
    config = hyperfabric.params.get("config")

    path = "/fabrics/{}/nodes"
    update_path = "/fabrics/{}/nodes/{}"

    existing_nodes = hyperfabric.query_obj(path.format(fabric_name), ignore_not_found_error=True).get("nodes", [])
    hyperfabric.existing = deepcopy(existing_nodes)
    hyperfabric.previous = deepcopy(existing_nodes)

    changed = False

    if state == "merged" or state == "present":
        for config_node in config:
            found = False
            cleaned_config_node = {}
            for key, value in config_node.items():
                if value and key not in ["node_name", "model", "pid"]:
                    if key == "model_name":
                        cleaned_config_node["modelName"] = value
                    else:
                        cleaned_config_node[key] = value
            for existing_node in existing_nodes:
                if cleaned_config_node.get("name") == existing_node.get("name"):
                    found = True
                    new_node = existing_node
                    del new_node["deviceId"]
                    change_found = False
                    for key, value in cleaned_config_node.items():
                        if new_node.get(key) != value:
                            change_found = True
                            new_node[key] = value

                    cleaned_new_node = {}
                    for key, value in new_node.items():
                        if value:
                            cleaned_new_node[key] = value
                    if change_found:
                        hyperfabric.request(update_path.format(fabric_name, existing_node.get("nodeId")), method="PUT", data=cleaned_new_node)
                        changed = True
            if found == False:
                hyperfabric.request(path.format(fabric_name), method="POST", data={"nodes": [cleaned_config_node]})
                changed = True

    if state == "deleted" or state == "absent":
        for config_node in config:
            for existing_node in existing_nodes:
                if config_node.get("name") == existing_node.get("name"):
                    hyperfabric.request(update_path.format(fabric_name, existing_node.get("nodeId")), method="DELETE")
                    changed = True

    # hyperfabric.existing = {}
    if changed == True:
        hyperfabric.existing = hyperfabric.query_obj(path.format(fabric_name)).get("nodes", [])
        hyperfabric.result["changed"] = changed

    hyperfabric.exit_json()


if __name__ == "__main__":
    main()
