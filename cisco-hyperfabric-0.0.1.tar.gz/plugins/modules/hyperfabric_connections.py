#!/usr/bin/python
# -*- coding: utf-8 -*-

# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.
#
# SPDX-License-Identifier: MPL-2.0

# Copyright: (c) 2025, Lionel Hercot (@lhercot) <lhercot@cisco.com>

from __future__ import absolute_import, division, print_function

__metaclass__ = type

ANSIBLE_METADATA = {"metadata_version": "1.1", "status": ["preview"], "supported_by": "community"}

DOCUMENTATION = r"""
---
module: hyperfabric_connections
version_added: "0.0.1"
short_description: Manages Nexus Hyperfabric fabric connections
description:
- Manages Cisco Nexus Hyperfabric fabric connections
author:
- Lionel Hercot (@lhercot)
options:
  state:
    description:
    - The behavior to use to modify the Hyperfabric configuration during module completion.
    type: str
    choices:
      - merged
      - present
      - deleted
      - absent
    default: merged
  fabric_name:
    description:
    - The name of the Fabric.
    type: str
    required: true
  config:
    description:
    - List of details of the fabric connections being managed.
    type: list
    elements: dict
    suboptions:
      local:
        description:
        - A map that represents the local side of the Connection.
        type: dict
        required: true
        suboptions:
          node_name:
            description:
            - The name of a Node used as local side of this Connection.
            type: str
            required: true
          port_name:
            description:
            - The name of the Port on the Node used as local side of this Connection.
            type: str
            required: true
      remote:
        description:
        - A map that represents the remote side of the Connection.
        type: dict
        required: true
        suboptions:
          node_name:
            description:
            - The name of a Node used as remote side of this Connection.
            type: str
            required: true
          port_name:
            description:
            - The name of the Port on the Node used as remote side of this Connection.
            type: str
            required: true
      description:
        description:
        - The description is a user defined field to store notes about the Connection.
        type: str
      pluggable:
        description:
        - The type of pluggable used for the Connection.
        type: str
extends_documentation_fragment:
- cisco.hyperfabric.modules
- cisco.hyperfabric.check_mode
"""

EXAMPLES = r"""
- name: Create connections
  cisco.hyperfabric.hyperfabric_connections:  
    state: merged
    fabric_name: ansible-fabric-1
    config:
      - local:
          node_name: leaf-1
          port_name: Ethernet1_1
        remote:
          node_name: spine-1
          port_name: Ethernet1_1
      - local:
          node_name: leaf-2
          port_name: Ethernet1_2
        remote:
          node_name: spine-1
          port_name: Ethernet1_2
  register: create_connections

- name: Delete connections
  cisco.hyperfabric.hyperfabric_connections:  
    state: deleted
    fabric_name: ansible-fabric-1
    config:
      - local:
          node_name: leaf-1
          port_name: Ethernet1_1
        remote:
          node_name: spine-1
          port_name: Ethernet1_1
      - local:
          node_name: leaf-2
          port_name: Ethernet1_2
        remote:
          node_name: spine-1
          port_name: Ethernet1_2
  register: delete_connections
"""

RETURN = r"""
"""

from copy import deepcopy
from datetime import datetime as dt, timedelta
from ansible.module_utils.basic import AnsibleModule
from ansible_collections.cisco.hyperfabric.plugins.module_utils.hyperfabric import HyperfabricModule, hyperfabric_argument_spec


def target_spec():
    return dict(
        node_name=dict(type="str", required=True),
        port_name=dict(type="str", required=True),
    )


def connection_config_spec():
    return dict(
        local=dict(type="dict", options=target_spec(), required=True),
        remote=dict(type="dict", options=target_spec(), required=True),
        description=dict(type="str"),
        pluggable=dict(type="str"),
    )


def main():
    argument_spec = hyperfabric_argument_spec()
    argument_spec.update(
        fabric_name=dict(type="str", required=True),
        config=dict(type="list", elements="dict", options=connection_config_spec()),
        state=dict(
            default="merged",
            choices=["merged", "present", "absent", "deleted"],
        ),
    )

    module = AnsibleModule(
        argument_spec=argument_spec,
        supports_check_mode=True,
    )

    hyperfabric = HyperfabricModule(module)

    fabric_name = hyperfabric.params.get("fabric_name")
    state = hyperfabric.params.get("state")
    config = hyperfabric.params.get("config")

    path = "/fabrics/{}/connections"
    update_path = "/fabrics/{}/connections/{}"

    existing_connections = hyperfabric.query_obj(path.format(fabric_name), ignore_not_found_error=True).get("connections", [])
    hyperfabric.existing = deepcopy(existing_connections)
    hyperfabric.previous = deepcopy(existing_connections)

    changed = False

    if state == "merged" or state == "present":
        for config_connection in config:
            found = False
            cleaned_config_connection = {}
            for key, value in config_connection.items():
                if value and key not in ["connection_name", "model", "pid"]:
                    if key == "node_name":
                        cleaned_config_connection["nodeId"] = value
                    elif key == "port_name":
                        cleaned_config_connection["portName"] = value
                    else:
                        cleaned_config_connection[key] = value
            for existing_connection in existing_connections:
                if config_connection.get("remote", {}).get("node_name") == existing_connection.get("remote", {}).get("nodeName") and config_connection.get("remote", {}).get("port_name") == existing_connection.get("remote", {}).get("portName") and config_connection.get("local", {}).get("node_name") == existing_connection.get("local", {}).get("nodeName") and config_connection.get("local", {}).get("port_name") == existing_connection.get("local", {}).get("portName"):
                    found = True
                    new_connection = existing_connection
                    # del new_connection["deviceId"]
                    change_found = False
                    if cleaned_config_connection.get("description") != existing_connection.get("description") or cleaned_config_connection.get("pluggable") != existing_connection.get("pluggable"):
                      new_connection["description"] = cleaned_config_connection.get("description")
                      new_connection["pluggable"] = cleaned_config_connection.get("pluggable")
                      change_found = True

                    cleaned_new_connection = {}
                    for key, value in new_connection.items():
                        if value:
                            cleaned_new_connection[key] = value
                    if change_found:
                        hyperfabric.request(update_path.format(fabric_name, existing_connection.get("id")), method="DELETE")
                        hyperfabric.request(path.format(fabric_name), method="POST", data={"connections": [cleaned_new_connection]})
                        changed = True
            if found == False:
                hyperfabric.request(path.format(fabric_name), method="POST", data={"connections": [cleaned_config_connection]})
                changed = True

    if state == "deleted" or state == "absent":
        for config_connection in config:
            for existing_connection in existing_connections:
                if config_connection.get("node_name") == existing_connection.get("nodeName") and config_connection.get("port_name") == existing_connection.get("portName"):
                    hyperfabric.request(update_path.format(fabric_name, existing_connection.get("id")), method="DELETE")
                    changed = True

    # hyperfabric.existing = {}
    if changed == True:
        hyperfabric.existing = hyperfabric.query_obj(path.format(fabric_name)).get("connections", [])
        hyperfabric.result["changed"] = changed

    hyperfabric.exit_json()


if __name__ == "__main__":
    main()
