#!/usr/bin/python
# -*- coding: utf-8 -*-

# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.
#
# SPDX-License-Identifier: MPL-2.0

# Copyright: (c) 2025, Lionel Hercot (@lhercot) <lhercot@cisco.com>

from __future__ import absolute_import, division, print_function

__metaclass__ = type

ANSIBLE_METADATA = {"metadata_version": "1.1", "status": ["preview"], "supported_by": "community"}

DOCUMENTATION = r"""
---
module: hyperfabric_fabrics
version_added: "0.0.1"
short_description: Manages Nexus Hyperfabric fabrics
description:
- Manages Cisco Nexus Hyperfabric fabrics
author:
- Lionel Hercot (@lhercot)
options:
  state:
    description:
    - The behavior to use to modify the Hyperfabric configuration during module completion.
    type: str
    choices:
      - merged
      - present
      - deleted
      - absent
    default: merged
  config:
    description:
    - List of details of the fabric being managed.
    type: list
    elements: dict
    suboptions:
      name:
        description:
        - The name of the Fabric.
        type: str
        required: true
        aliases: [ fabric_name ]
      description:
        description:
        - The description is a user defined field to store notes about the Fabric.
        type: str
      topology:
        description:
        - The topology type of the Fabric.
        type: str
        choices: [ MESH, SPINE_LEAF ]
        default: MESH
      address:
        description:
        - The physical street address where the Fabric is located.
        type: str
      city:
        description:
        - The city in which the Fabric is located.
        type: str
      country:
        description:
        - The country in which the Fabric is located.
        type: str
      location:
        description:
        - The location is a user defined location of the Fabric.
        type: str
      labels:
        description:
        - A list of user-defined labels that can be used for grouping and filtering Fabrics.
        type: list
        elements: string
      annotations:
        description:
        - A list of key-value annotations to store user-defined data including complex data such as JSON.
        type: list
        elements: dict
        suboptions:
          name:
            description:
            - The name used to uniquely identify the annotation.
            type: str
            required: true
          value:
            description:
            - The value of the annotation.
            type: str
            required: true
          data_type:
            description:
            - The type of data stored in the value of the annotation.
            type: str
            choices: [ STRING, INT32, UINT32, INT64, UINT64, BOOL, TIME, UUID, DURATION, JSON ]
            default: STRING
extends_documentation_fragment:
- cisco.hyperfabric.modules
- cisco.hyperfabric.check_mode
"""

EXAMPLES = r"""
- name: Create a fabric
  cisco.hyperfabric.hyperfabric_fabrics:
    config:
    - name: my-fabric
      description: My super Hyperfabric
    state: merged

- name: Delete a fabric
  cisco.hyperfabric.hyperfabric_fabrics:
    config:
    - name: my-fabric
    state: deleted
"""

RETURN = r"""
"""

from copy import deepcopy
from datetime import datetime as dt, timedelta
from ansible.module_utils.basic import AnsibleModule
from ansible_collections.cisco.hyperfabric.plugins.module_utils.hyperfabric import HyperfabricModule, hyperfabric_argument_spec


def annotations_spec():
    return dict(
        name=dict(type="str", required=True),
        value=dict(type="str", required=True),
        data_type=dict(type="str", default="STRING", choices=["STRING", "INT32", "UINT32", "INT64", "UINT64", "BOOL", "TIME", "UUID", "DURATION", "JSON"])
    )


def fabric_config_spec():
    return dict(
        name=dict(type="str", required=True, aliases=["fabric_name"]),
        description=dict(type="str"),
        topology=dict(type="str"),
        address=dict(type="str"),
        city=dict(type="str"),
        country=dict(type="str"),
        location=dict(type="str"),
        labels=dict(type="list", elements="str"),
        annotations=dict(type="list", elements="dict", options=annotations_spec()),
    )


def main():
    argument_spec = hyperfabric_argument_spec()
    argument_spec.update(
        config=dict(type="list", elements="dict", options=fabric_config_spec()),
        state=dict(
            default="merged",
            choices=["merged", "present", "absent", "deleted"],
        ),
    )

    module = AnsibleModule(
        argument_spec=argument_spec,
        supports_check_mode=True,
    )

    hyperfabric = HyperfabricModule(module)

    state = hyperfabric.params.get("state")
    config = hyperfabric.params.get("config")

    path = "/fabrics"
    update_path = "/fabrics/{}"

    existing_fabrics = hyperfabric.query_obj(path).get("fabrics", [])
    hyperfabric.existing = deepcopy(existing_fabrics)
    hyperfabric.previous = deepcopy(existing_fabrics)


    changed = False

    if state == "merged" or state == "present":
        for config_fabric in config:
            found = False
            cleaned_config_fabric = {}
            for key, value in config_fabric.items():
                if value:
                    cleaned_config_fabric[key] = value
            for existing_fabric in existing_fabrics:
                if cleaned_config_fabric.get("name") == existing_fabric.get("name"):
                    found = True
                    new_fabric = existing_fabric
                    change_found = False
                    for key, value in cleaned_config_fabric.items():
                        if new_fabric.get(key) != value:
                            change_found = True
                            new_fabric[key] = value

                    cleaned_new_fabric = {}
                    for key, value in new_fabric.items():
                        if value:
                            cleaned_new_fabric[key] = value
                    if change_found:
                        hyperfabric.request(update_path.format(existing_fabric.get("fabricId")), method="PUT", data=cleaned_new_fabric)
                        changed = True
            if found == False:
                hyperfabric.request(path, method="POST", data={"fabrics": [cleaned_config_fabric]})
                changed = True

    if state == "deleted" or state == "absent":
        for config_fabric in config:
            for existing_fabric in existing_fabrics:
                if config_fabric.get("name") == existing_fabric.get("name"):
                    hyperfabric.request(update_path.format(existing_fabric.get("fabricId")), method="DELETE")
                    changed = True

    # hyperfabric.existing = {}
    if changed == True:
        hyperfabric.existing = hyperfabric.query_obj(path).get("fabrics", [])
        hyperfabric.result["changed"] = changed

    hyperfabric.exit_json()


if __name__ == "__main__":
    main()
