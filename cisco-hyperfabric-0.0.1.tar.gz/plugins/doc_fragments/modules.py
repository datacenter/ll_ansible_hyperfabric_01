# -*- coding: utf-8 -*-

# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.
#
# SPDX-License-Identifier: MPL-2.0

# Copyright: (c) 2025, Lionel Hercot (@lhercot) <lhercot@cisco.com>

from __future__ import absolute_import, division, print_function

__metaclass__ = type


class ModuleDocFragment(object):
    # Standard files documentation fragment
    DOCUMENTATION = r"""
options:
  host:
    description:
    - IP Address or hostname of the Nexus Hyperfabric host.
    - If the value is not specified in the task, the value of environment variable C(HYPERFABRIC_HOST) will be used instead.
    type: str
    aliases: [ hostname ]
    default: hyperfabric.cisco.com
  port:
    description:
    - Port number to be used for the REST connection.
    - The default value depends on parameter `use_ssl`.
    - If the value is not specified in the task, the value of environment variable C(HYPERFABRIC_PORT) will be used instead.
    type: int
    default: 443
  output_level:
    description:
    - Influence the output of this Hyperfabric module.
    - C(normal) means the standard output, incl. C(current) dict
    - C(info) adds informational output, incl. C(previous), C(proposed) and C(sent) dicts
    - C(debug) adds debugging output, incl. C(filter_string), C(method), C(response), C(status) and C(url) information
    - If the value is not specified in the task, the value of environment variable C(HYPERFABRIC_OUTPUT_LEVEL) will be used instead.
    type: str
    choices: [ debug, info, normal ]
    default: normal
  timeout:
    description:
    - The socket level timeout in seconds.
    - If the value is not specified in the task, the value of environment variable C(HYPERFABRIC_TIMEOUT) will be used instead.
    type: int
    default: 30
  use_proxy:
    description:
    - If C(no), it will not use a proxy, even if one is defined in an environment variable on the target hosts.
    - If the value is not specified in the task, the value of environment variable C(HYPERFABRIC_USE_PROXY) will be used instead.
    type: bool
  use_ssl:
    description:
    - If C(no), an HTTP connection will be used instead of the default HTTPS connection.
    - If the value is not specified in the task, the value of environment variable C(HYPERFABRIC_USE_SSL) will be used instead.
    type: bool
  validate_certs:
    description:
    - If C(no), SSL certificates will not be validated.
    - This should only set to C(no) when used on personally controlled sites using self-signed certificates.
    - If the value is not specified in the task, the value of environment variable C(HYPERFABRIC_VALIDATE_CERTS) will be used instead.
    type: bool
requirements:
- Nexus Dashboard v2.0 or newer
notes:
- Please read the :ref:`hyperfabric_guide` for more detailed information on how to manage your Hyperfabric infrastructure using Ansible.
"""
