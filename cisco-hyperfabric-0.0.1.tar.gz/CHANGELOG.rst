======================================================
Cisco Nexus Hyperfabric Ansible Collection Release Notes
======================================================

.. contents:: Topics

v0.1.0
======

Release Summary
---------------

Initial release of Cisco Nexus Hyperfabric collection

New Plugins
-----------

Httpapi
~~~~~~~

- cisco.hyperfabric.hyperfabric - Cisco Nexus Hyperfabric Ansible HTTPAPI Plugin.

New Modules
-----------

- cisco.hyperfabric.hyperfabric_fabrics - Manages Nexus Hyperfabric fabrics
- cisco.hyperfabric.hyperfabric_nodes - Manages Nexus Hyperfabric fabric nodes
- cisco.hyperfabric.hyperfabric_connections - Manages Nexus Hyperfabric fabric connections
